# PeptiCraft 真实数据导出包

**来源**：`igem_peptides` @ PostgreSQL 16 —— 从移动硬盘 `Elements/backup/pg_backup` 的
`pg_basebackup -Ft` 物理备份（2026-10-10 14:46 CST 拍摄）恢复后导出。
**导出时间**：2026-10-11　**导出机器**：Ubuntu（Filo）　**目标**：Milo 的 macOS

---

## 一、包内容

```
pg_export_20261011/
├── README.md                      本文件
├── load.sql                       ★ 一键装载脚本（psql -f load.sql）
├── schema/
│   └── schema_full.sql            整库 DDL（补上 netmhc_score 等仓库里没有的建表语句）
├── data/
│   ├── small_tables.dump          参考层+构造层，custom 格式（58 KB）
│   ├── subset.dump                肽层+分数层子集，custom 格式（403 KB）
│   └── csv/
│       ├── backbone_proteins.csv           5 行
│       ├── linkers.csv                     6 行
│       ├── linker_library.csv             15 行  ★ 唯一副本
│       ├── constructs.csv                496 行
│       ├── peptides_subset.csv           496 行
│       └── peptide_enrichment_subset.csv 11,736 行
└── aggregates/
    ├── tool_counts.csv            ★ 42 个工具的条数（必须冻结的那份）
    ├── coverage_recomputed.csv    覆盖视图的真实输出（12 个工具，全 100%）
    ├── coverage_view.sql          覆盖视图 DDL
    ├── counts_verification.csv    实测行数 vs 之前报的数
    ├── VIEW_GAPS.md               ⚠️ 视图漏掉 30 个工具（含 iMFP-LG 5 通道）
    ├── aggregate_run.log          聚合执行原始日志
    └── subsets_run.log            子集导出原始日志
```

**总共约 3.9 MB。**

---

## 二、怎么用

### 最省事：CSV 路径

```bash
cd pg_export_20261011
psql -h 127.0.0.1 -U igem_user -d <你的库名> -f load.sql
```

`load.sql` 会按外键顺序装载、对齐序列，最后打印自检行数。
期望结果：`5 / 6 / 15 / 496 / 496 / 11736`

> ⚠️ `load.sql` 里有 `TRUNCATE ... CASCADE`，会清掉本地样例数据。
> 要保留样例就把 `[0]` 那段注释掉。

### 保真度更高：custom 路径

```bash
pg_restore -h 127.0.0.1 -U igem_user -d <你的库名> --data-only --disable-triggers data/small_tables.dump
pg_restore -h 127.0.0.1 -U igem_user -d <你的库名> --data-only --disable-triggers data/subset.dump
```

custom 格式对数组、JSONB、NULL、外键顺序的处理最稳。
（`--disable-triggers` 需要超级用户；没有就走 CSV。）

### 只要 schema

```bash
psql -h 127.0.0.1 -U igem_user -d <你的库名> -f schema/schema_full.sql
```

---

## 三、必须知道的三件事

### 1. ⚠️ 覆盖视图漏掉了 30 个工具

`v_peptide_enrichment_coverage` 的 `VALUES` 列表里只写死了 **12 个工具**，
但 `peptide_enrichment` 实有 **42 个**。详见 `aggregates/VIEW_GAPS.md`。

漏掉的是：**iMFP-LG 5 个通道**（ACP/ADP/AHP/AIP/AMP）、**24 个 mhcflurry 等位基因通道**、
`aopxsvm`、`bepipred3`。

> 之前以为漏的是"iMFP-LG 两个通道"——实际是 5 个。

那 42 个工具的完整条数在 **`aggregates/tool_counts.csv`**（这份冻结了，子集取多小都不影响首页统计）。

### 2. ★ `linker_library` 这 15 行是唯一副本

原始整理稿已随早期前端删除。`data/csv/linker_library.csv` 是**不依赖 PostgreSQL、
用任何文本编辑器/Excel 都能打开**的人类可读备份。**别弄丢，也别只用 dump 留着。**
（本包之外另存了一份在 `~/Desktop/linker_library_备份_20261011.csv` 和移动硬盘上。）

### 3. `peptides` 精确是 20,248,885 行

`pg_class.reltuples` 给的估算是 19,618,972，**偏低 63 万，别用估算值**。
精确 `count(*)` 结果与之前报的 20,248,885 一致 ✅

---

## 四、行数核对

| 表 | 实测（精确） | 之前报的 | 结论 |
|---|---|---|---|
| `constructs` | 496 | 496 | ✅ |
| `linker_library` | 15 | 15 | ✅ |
| `linkers` | 6 | 6 | ✅ |
| `backbone_proteins` | 5 | — | 小表 |
| `peptides` | **20,248,885** | 20,248,885 | ✅（估算是错的）|
| `peptide_enrichment` | **367,717,240** | 约 3.78 亿 | 接近，实际低约 1,030 万 |
| `netmhc_score` | 147,540,784（估算，未扫） | 约 1.475 亿 | 未精确核 |

明细见 `aggregates/counts_verification.csv`。

---

## 五、没有导的东西（确认服务不用）

| 表 | 大小 | 为什么不导 |
|---|---|---|
| `netmhc_score` | 35 GB | 服务从不查询；但它的**建表语句**已随 `schema_full.sql` 带走 |
| `_bkp_anoxpepred_20260823` | 4 GB | 8/23 的 anoxpepred 备份表，与现网数据重复 |
| `dataset_manifest` | 10 行 | 服务不查 |
| `peptide_metadata` | 0 行 | 空表 |
| `scaffold_patent_records` / `scaffold_groups` / `scaffold_experiments` | 27 / 11 / 12 行 | 只在注释里被提到，没有任何查询用到 |
| `scaffold_library` / `scaffold_library_sequences` | 8 / 16 行 | 本地已经有了 |

---

## 六、子集为什么是 11,736 行

496 条构造肽 × 42 个工具，但并非每条肽都有全部工具的分数：

- **18 个工具 × 496 = 8,928 行**（这些工具覆盖全部肽）
- **24 个 mhcflurry 通道 × 117 = 2,808 行**（只有长度 5–15 的肽有 mhcflurry 分数）
- 合计 **11,736 行**（496 条不同的肽）

---

## 七、恢复过程记录（备查）

备份是**物理备份**（`pg_basebackup -Ft`），不能直接读文件，必须把 PostgreSQL 服务端起来：

1. 备份在 NTFS 移动硬盘上，文件权限 `0600 uid=136`，普通用户读不了 → 用 Docker 容器内 root 读
2. `base.tar`（176 GiB）解压到移动硬盘（系统盘只剩 103 GB，放不下）→ 耗时 **1 小时 36 分**
3. `pg_wal.tar` 内是**裸文件名**，必须解到 `data/pg_wal/` 而不是数据根目录
4. **备份里没有 `postgresql.conf` / `pg_hba.conf`**——原库配置在数据目录外，
   `pg_basebackup` 不收录。补一份最小配置才启动得起来
5. 以 uid=1000 启动 `postgres:16-alpine`，靠 `backup_label` + `pg_wal` 自动完成恢复：
   ```
   LOG:  starting backup recovery with redo LSN 189/E0000028, checkpoint LSN 189/E0000060, on timeline ID 1
   LOG:  consistent recovery state reached at 189/E0000138
   LOG:  database system is ready to accept connections
   ```
6. **原库 locale 是 `zh_CN.UTF-8`，构建于 glibc 2.39**（Ubuntu 24.04）。
   容器里必须先生成这个 locale，否则 glibc 版会直接
   `FATAL: database locale is incompatible with operating system` 连不上。
   当前容器是 glibc 2.41，需 `ALTER DATABASE ... REFRESH COLLATION VERSION` 后才能建库。

**原备份目录全程只读挂载，未做任何写入。** 解压副本在
`Elements/pg_restore/data/`（176 GB），确认不再需要后可删除。

---

## 八、交付物的验证结果

**不是"看着对"，是真的还原过一遍。** 用本包自己的产物在临时库里跑通了完整回路：

```
--- 1) 用交付的 schema_full.sql 建表 ---
    建表完成，表数: 15
--- 2) 用交付的两个 custom dump 灌数据 ---
    灌入完成
--- 3) 行数核对 ---
 backbone_proteins  |     5
 linkers            |     6
 linker_library     |    15
 peptides           |   496
 constructs         |   496
 peptide_enrichment | 11736
--- 4) 外键完整性 + 业务 JOIN ---
 constructs 缺肽引用        | 0
 constructs 缺骨架引用      | 0
 constructs 缺连接片段引用  | 0
 三表 JOIN 总行数           | 11736
```

**行数与预期完全一致；外键零悬空；构造→肽→分数三表 JOIN 通顺。**
验证用的临时库已删除。

