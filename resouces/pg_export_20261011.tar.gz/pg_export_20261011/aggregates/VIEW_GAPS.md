# 覆盖视图的缺口 —— 给 Milo 的更正

## `v_peptide_enrichment_coverage` 只列了 12 个工具

```
algpred2, amp-esm, anoxpepred, anoxpepred-chelating, anoxpepred-frs,
hemopi2, mhcflurry, plm4cpps, sodope, temstapro, tipred, toxinpred3
```

## 但 `peptide_enrichment` 实有 **42 个工具**

视图靠 `LEFT JOIN` 挂在这 12 个工具上，所以**另外 30 个工具它的 `done_count` / `coverage_pct` 全是 0**——
这不是"没数据"，是视图根本没列它们。

### 漏掉的 30 个

| 类别 | 工具 | 行数 |
|---|---|---|
| **iMFP-LG 通道（5 个，不是 2 个）** | `imfp_lg_ACP` `imfp_lg_ADP` `imfp_lg_AHP` `imfp_lg_AIP` `imfp_lg_AMP` | 各 20,248,885 |
| **mhcflurry 等位基因（24 个）** | `mhcflurry-A0201` `-A0203` `-A0206` `-A0207` `-A0301` `-A1101` `-A2402` `-A2601` `-A3101` `-A3303` `-B0702` `-B1301` `-B1502` `-B3501` `-B3802` `-B3901` `-B4001` `-B4402` `-B4601` `-B5101` `-B5201` `-B5401` `-B5801` | 各 134,888 |
| 其他 | `aopxsvm` | 20,248,883（**比满额少 2 行**）|
| 其他 | `bepipred3` | 20,248,885 |

> ⚠️ 之前说"视图漏掉 iMFP-LG 两个通道"——实际是 **5 个通道**，另有 **24 个 mhcflurry 等位基因通道**同样没被收录。

## 真实覆盖率（视图里那 12 个工具）

```
algpred2             done=20248885  eligible=20248885  coverage=100.00%
amp-esm              done=20248885  eligible=20248885  coverage=100.00%
anoxpepred           done=20248885  eligible=20248885  coverage=100.00%
anoxpepred-chelating done=20248885  eligible=20248885  coverage=100.00%
anoxpepred-frs       done=20248885  eligible=20248885  coverage=100.00%
hemopi2              done=20248885  eligible=20248885  coverage=100.00%
mhcflurry            done=  134888  eligible=  134888  coverage=100.00%
plm4cpps             done=20248885  eligible=20248885  coverage=100.00%
sodope               done=20248885  eligible=20248885  coverage=100.00%
temstapro            done=20248885  eligible=20248885  coverage=100.00%
tipred               done=20248885  eligible=20248885  coverage=100.00%
toxinpred3           done=20248885  eligible=20248885  coverage=100.00%
```

**全部 100%。** 本地显示 0% 是因为本地 `peptide_enrichment` 只有 30 行样例数据。

---

## 顺带查清的两件事

### 1. `peptides` 到底多少行？
**20,248,885**（精确 `count(*)`）。
之前估算值 `pg_class.reltuples` 给的是 19,618,972，偏低约 63 万——**以精确值为准，Milo 报的 20,248,885 是对的。**

### 2. 那张 `_bkp_anoxpepred_20260823` 是什么？
- 结构 = `peptide_enrichment` 的副本（peptide_id / tool / score / label / details / scored_at）
- 内容 = **只有 `anoxpepred` 一个工具，20,248,885 行**（8.4 GB，占 4 GB 堆）
- 它和 `peptides` 行数完全相同，是因为 anoxpepred 对每条肽都有且仅有一行（1:1 全覆盖）——**纯属数字巧合**，不是同一份数据
- 当前 `peptide_enrichment` 里 anoxpepred 系列 3 个工具各 20,248,885 行，都在，没丢

### 3. 分数层实际覆盖
496 条构造肽 × 42 工具，实际拿到 **11,736 行**：
- 18 个工具 × 496 = 8,928 行
- 24 个 mhcflurry 通道 × 117 = 2,808 行（只有长度 5–15 的肽有 mhcflurry 分数）
- 8,928 + 2,808 = **11,736** ✅
