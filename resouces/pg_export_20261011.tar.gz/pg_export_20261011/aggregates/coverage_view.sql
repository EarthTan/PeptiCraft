--
-- PostgreSQL database dump
--

\restrict 4CVYgZkSgr3Lavt65gwourNhUzpXg8Tsz20M0NtHragbCYrv5MhYedUgdGJ6ptd

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: v_peptide_enrichment_coverage; Type: VIEW; Schema: public; Owner: igem
--

CREATE VIEW public.v_peptide_enrichment_coverage AS
 SELECT t.tool,
    COALESCE(c.done, (0)::bigint) AS done_count,
    COALESCE(c.tool_eligible, (0)::bigint) AS eligible_count,
        CASE
            WHEN (COALESCE(c.tool_eligible, (0)::bigint) = 0) THEN (0)::numeric
            ELSE round(((100.0 * (c.done)::numeric) / (c.tool_eligible)::numeric), 2)
        END AS coverage_pct
   FROM (( VALUES ('toxinpred3'::text,'1-30'::text), ('tipred'::text,'1-30'::text), ('algpred2'::text,'1-30'::text), ('sodope'::text,'1-30'::text), ('anoxpepred'::text,'1-30'::text), ('anoxpepred-frs'::text,'1-30'::text), ('anoxpepred-chelating'::text,'1-30'::text), ('hemopi2'::text,'1-40'::text), ('plm4cpps'::text,'length_supported'::text), ('temstapro'::text,'length_supported'::text), ('mhcflurry'::text,'5-15'::text), ('amp-esm'::text,'1-30'::text)) t(tool, eligible_filter)
     LEFT JOIN ( SELECT peptide_enrichment.tool,
            count(*) AS done,
                CASE peptide_enrichment.tool
                    WHEN 'mhcflurry'::text THEN ( SELECT count(*) AS count
                       FROM public.peptides
                      WHERE ((peptides.length >= 5) AND (peptides.length <= 15)))
                    WHEN 'hemopi2'::text THEN ( SELECT count(*) AS count
                       FROM public.peptides
                      WHERE (peptides.length <= 40))
                    ELSE ( SELECT count(*) AS count
                       FROM public.peptides)
                END AS tool_eligible
           FROM public.peptide_enrichment
          GROUP BY peptide_enrichment.tool) c ON (((c.tool)::text = t.tool)))
  ORDER BY
        CASE
            WHEN (COALESCE(c.tool_eligible, (0)::bigint) = 0) THEN (0)::numeric
            ELSE round(((100.0 * (c.done)::numeric) / (c.tool_eligible)::numeric), 2)
        END DESC NULLS LAST, t.tool;


ALTER VIEW public.v_peptide_enrichment_coverage OWNER TO igem;

--
-- PostgreSQL database dump complete
--

\unrestrict 4CVYgZkSgr3Lavt65gwourNhUzpXg8Tsz20M0NtHragbCYrv5MhYedUgdGJ6ptd

