-- ============================================================================
--  PeptiCraft / iGEM 2026 平台 —— 从真实库导入所需数据
-- ----------------------------------------------------------------------------
--  数据来源 : igem_peptides @ PostgreSQL 16（物理备份 pg_basebackup -Ft 恢复）
--  备份时间 : 2026-10-10 14:46 CST
--  导出时间 : 2026-10-11
--  导出人   : Filo（Ubuntu 侧）
-- ----------------------------------------------------------------------------
--  用法（在本包根目录下执行）:
--      psql -h 127.0.0.1 -U igem_user -d <你的库名> -f load.sql
--
--  装载顺序有讲究：constructs 的外键指向 backbone_proteins / linkers / peptides，
--  peptide_enrichment 的外键指向 peptides，所以必须按下面的顺序来。
-- ============================================================================

\set ON_ERROR_STOP on

BEGIN;

-- ---------------------------------------------------------------------------
-- [0] 清掉本地样例数据（如果你要保留本地样例，把这一段注释掉）
--     注意：TRUNCATE ... CASCADE 会连带清掉引用这些表的行
-- ---------------------------------------------------------------------------
TRUNCATE public.peptide_enrichment,
         public.constructs,
         public.peptides,
         public.backbone_proteins,
         public.linkers,
         public.linker_library
  CASCADE;

-- ---------------------------------------------------------------------------
-- [1] 参考层（小表，全量）
-- ---------------------------------------------------------------------------
\copy public.backbone_proteins  FROM 'data/csv/backbone_proteins.csv'  CSV HEADER
\copy public.linkers            FROM 'data/csv/linkers.csv'            CSV HEADER
\copy public.linker_library     FROM 'data/csv/linker_library.csv'     CSV HEADER

-- ---------------------------------------------------------------------------
-- [2] 肽层（只含 496 条 constructs 引用到的肽）
-- ---------------------------------------------------------------------------
\copy public.peptides           FROM 'data/csv/peptides_subset.csv'    CSV HEADER

-- ---------------------------------------------------------------------------
-- [3] 构造层
-- ---------------------------------------------------------------------------
\copy public.constructs         FROM 'data/csv/constructs.csv'         CSV HEADER

-- ---------------------------------------------------------------------------
-- [4] 分数层（只含上述 496 条肽的 11,736 条分数行）
-- ---------------------------------------------------------------------------
\copy public.peptide_enrichment FROM 'data/csv/peptide_enrichment_subset.csv' CSV HEADER

-- ---------------------------------------------------------------------------
-- [5] 对齐序列，避免以后 INSERT 撞主键
--     注意 linker_library 没有序列（主键是文本 id，如 'LK_GGGGS'）
-- ---------------------------------------------------------------------------
SELECT setval('public.backbone_proteins_id_seq', (SELECT max(id) FROM public.backbone_proteins));
SELECT setval('public.linkers_id_seq',           (SELECT max(id) FROM public.linkers));
SELECT setval('public.peptides_id_seq',          (SELECT max(id) FROM public.peptides));
SELECT setval('public.constructs_id_seq',        (SELECT max(id) FROM public.constructs));

COMMIT;

-- ---------------------------------------------------------------------------
-- [6] 装载后自检
-- ---------------------------------------------------------------------------
SELECT 'backbone_proteins'  AS tbl, count(*) FROM public.backbone_proteins
UNION ALL SELECT 'linkers',            count(*) FROM public.linkers
UNION ALL SELECT 'linker_library',     count(*) FROM public.linker_library
UNION ALL SELECT 'peptides',           count(*) FROM public.peptides
UNION ALL SELECT 'constructs',         count(*) FROM public.constructs
UNION ALL SELECT 'peptide_enrichment', count(*) FROM public.peptide_enrichment;

-- 期望结果: 5 / 6 / 15 / 496 / 496 / 11736

-- ============================================================================
--  备选路径（custom 格式，保真度更高）
-- ----------------------------------------------------------------------------
--  本包的 data/*.dump 是 pg_dump -Fc 产物，表名与原库一致，
--  用 pg_restore 装载可自动处理类型/数组/JSONB/空值：
--
--      pg_restore -h 127.0.0.1 -U igem_user -d <你的库名> \
--                 --data-only --disable-triggers data/small_tables.dump
--      pg_restore -h 127.0.0.1 -U igem_user -d <你的库名> \
--                 --data-only --disable-triggers data/subset.dump
--
--  注意：--disable-triggers 需要超级用户权限；没有的话就用上面的 CSV 路径。
-- ============================================================================
