--
-- PostgreSQL database dump
--

\restrict ivLVEeWwIDLbXtj8MRiX5KqnYVwbawfsPIkkymYVgN7ydlsKF0n40EIa1jSbJS2

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _bkp_anoxpepred_20260823; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public._bkp_anoxpepred_20260823 (
    peptide_id bigint,
    tool character varying(32),
    score real,
    label text,
    details jsonb,
    scored_at timestamp with time zone
);


ALTER TABLE public._bkp_anoxpepred_20260823 OWNER TO igem;

--
-- Name: backbone_proteins; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.backbone_proteins (
    id bigint NOT NULL,
    name text NOT NULL,
    type character varying(16) NOT NULL,
    sequence text NOT NULL,
    length integer NOT NULL,
    species text,
    common_name text,
    accession text,
    lab text,
    patent text,
    reference text,
    characteristics text,
    properties text,
    applications text,
    expression_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT backbone_proteins_type_check CHECK (((type)::text = ANY ((ARRAY['natural'::character varying, 'modified'::character varying, 'custom'::character varying])::text[])))
);


ALTER TABLE public.backbone_proteins OWNER TO igem;

--
-- Name: backbone_proteins_id_seq; Type: SEQUENCE; Schema: public; Owner: igem
--

CREATE SEQUENCE public.backbone_proteins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backbone_proteins_id_seq OWNER TO igem;

--
-- Name: backbone_proteins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: igem
--

ALTER SEQUENCE public.backbone_proteins_id_seq OWNED BY public.backbone_proteins.id;


--
-- Name: constructs; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.constructs (
    id bigint NOT NULL,
    direction character varying(32) NOT NULL,
    scenario text DEFAULT 'wound_careing'::text NOT NULL,
    backbone_id bigint,
    linker_id bigint,
    peptide_id bigint,
    full_sequence text NOT NULL,
    channel character varying(8),
    status character varying(16),
    rank integer,
    scores jsonb NOT NULL,
    delivery_scores jsonb NOT NULL,
    assessed_hemo boolean DEFAULT false NOT NULL,
    assessed_mhci boolean DEFAULT false NOT NULL,
    assessed_mhcii boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT constructs_channel_check CHECK (((channel)::text = ANY ((ARRAY['top'::character varying, 'bottom'::character varying])::text[]))),
    CONSTRAINT constructs_status_check CHECK (((status)::text = ANY ((ARRAY['passed'::character varying, 'failed_safety'::character varying, 'failed_score'::character varying, 'WIP'::character varying])::text[])))
);


ALTER TABLE public.constructs OWNER TO igem;

--
-- Name: constructs_id_seq; Type: SEQUENCE; Schema: public; Owner: igem
--

CREATE SEQUENCE public.constructs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.constructs_id_seq OWNER TO igem;

--
-- Name: constructs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: igem
--

ALTER SEQUENCE public.constructs_id_seq OWNED BY public.constructs.id;


--
-- Name: dataset_manifest; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.dataset_manifest (
    id bigint NOT NULL,
    source character varying(32) NOT NULL,
    source_version date NOT NULL,
    source_file text NOT NULL,
    source_file_sha256 character(64),
    source_file_bytes bigint,
    scan_started_at timestamp with time zone DEFAULT now() NOT NULL,
    scan_finished_at timestamp with time zone,
    status character varying(16) NOT NULL,
    rows_inserted bigint DEFAULT 0 NOT NULL,
    last_offset bigint,
    error_message text,
    CONSTRAINT dataset_manifest_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in_progress'::character varying, 'done'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.dataset_manifest OWNER TO igem;

--
-- Name: dataset_manifest_id_seq; Type: SEQUENCE; Schema: public; Owner: igem
--

CREATE SEQUENCE public.dataset_manifest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dataset_manifest_id_seq OWNER TO igem;

--
-- Name: dataset_manifest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: igem
--

ALTER SEQUENCE public.dataset_manifest_id_seq OWNED BY public.dataset_manifest.id;


--
-- Name: linker_library; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.linker_library (
    id text NOT NULL,
    name text NOT NULL,
    sequence text NOT NULL,
    length integer NOT NULL,
    rigidity text,
    flexible_count integer,
    rigid_count integer,
    rigidity_index real,
    unit_composition jsonb DEFAULT '[]'::jsonb NOT NULL,
    description text,
    reference text,
    priority_reason text,
    source_table text DEFAULT 'linker_library'::text NOT NULL,
    source_version date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT linker_library_length_check CHECK ((length > 0)),
    CONSTRAINT linker_library_rigidity_check CHECK (((rigidity IS NULL) OR (rigidity = ANY (ARRAY['Flexible'::text, 'Mostly Flexible'::text, 'Balanced'::text, 'Mostly Rigid'::text, 'Rigid'::text]))))
);


ALTER TABLE public.linker_library OWNER TO igem;

--
-- Name: linkers; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.linkers (
    id bigint NOT NULL,
    name text NOT NULL,
    sequence text NOT NULL,
    length integer NOT NULL,
    flexible_count integer NOT NULL,
    rigid_count integer NOT NULL,
    rigidity real,
    description text
);


ALTER TABLE public.linkers OWNER TO igem;

--
-- Name: linkers_id_seq; Type: SEQUENCE; Schema: public; Owner: igem
--

CREATE SEQUENCE public.linkers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.linkers_id_seq OWNER TO igem;

--
-- Name: linkers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: igem
--

ALTER SEQUENCE public.linkers_id_seq OWNED BY public.linkers.id;


--
-- Name: netmhc_score; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.netmhc_score (
    id bigint NOT NULL,
    peptide text NOT NULL,
    allele text NOT NULL,
    core text,
    rank_pct double precision,
    score double precision,
    bind_level text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.netmhc_score OWNER TO igem;

--
-- Name: netmhc_score_id_seq; Type: SEQUENCE; Schema: public; Owner: igem
--

CREATE SEQUENCE public.netmhc_score_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.netmhc_score_id_seq OWNER TO igem;

--
-- Name: netmhc_score_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: igem
--

ALTER SEQUENCE public.netmhc_score_id_seq OWNED BY public.netmhc_score.id;


--
-- Name: peptide_enrichment; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.peptide_enrichment (
    peptide_id bigint NOT NULL,
    tool character varying(32) NOT NULL,
    score real,
    label text,
    details jsonb,
    scored_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.peptide_enrichment OWNER TO igem;

--
-- Name: peptide_metadata; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.peptide_metadata (
    peptide_id bigint NOT NULL,
    parent_header text NOT NULL,
    parent_length integer,
    taxonomy text,
    pdb_id character varying(8),
    pdb_chain character varying(4),
    rna_frame smallint,
    source_file text NOT NULL,
    source_offset bigint
);


ALTER TABLE public.peptide_metadata OWNER TO igem;

--
-- Name: peptides; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.peptides (
    id bigint NOT NULL,
    sequence character varying(30) NOT NULL,
    length smallint NOT NULL,
    source character varying(32) NOT NULL,
    source_version date NOT NULL,
    source_accession text,
    seq_md5 character(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT peptides_length_check CHECK (((length >= 1) AND (length <= 30)))
);


ALTER TABLE public.peptides OWNER TO igem;

--
-- Name: peptides_id_seq; Type: SEQUENCE; Schema: public; Owner: igem
--

CREATE SEQUENCE public.peptides_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.peptides_id_seq OWNER TO igem;

--
-- Name: peptides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: igem
--

ALTER SEQUENCE public.peptides_id_seq OWNED BY public.peptides.id;


--
-- Name: scaffold_experiments; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.scaffold_experiments (
    id bigint NOT NULL,
    scaffold_group_key text NOT NULL,
    potential_application text,
    highest_level text,
    experiment_level text,
    specific_experiments text,
    principal_result text,
    result_location text,
    evidence_type_limitations text,
    source_version date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scaffold_experiments OWNER TO igem;

--
-- Name: scaffold_experiments_id_seq; Type: SEQUENCE; Schema: public; Owner: igem
--

CREATE SEQUENCE public.scaffold_experiments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scaffold_experiments_id_seq OWNER TO igem;

--
-- Name: scaffold_experiments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: igem
--

ALTER SEQUENCE public.scaffold_experiments_id_seq OWNED BY public.scaffold_experiments.id;


--
-- Name: scaffold_groups; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.scaffold_groups (
    scaffold_group_key text NOT NULL,
    scaffold_group_name text NOT NULL,
    potential_application text,
    highest_level text,
    source_version date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scaffold_groups OWNER TO igem;

--
-- Name: scaffold_library; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.scaffold_library (
    id text NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    category text,
    construct_cn text,
    applicant text NOT NULL,
    patent_family text,
    species text,
    length_aa integer,
    aa_sequence text,
    sequence_count integer DEFAULT 0 NOT NULL,
    application_tags text[] DEFAULT '{}'::text[] NOT NULL,
    route_ids text[] DEFAULT '{}'::text[] NOT NULL,
    material_forms text[] DEFAULT '{}'::text[] NOT NULL,
    max_evidence text,
    product_use text,
    potential_uses text,
    evidence_limits text,
    registrations text[] DEFAULT '{}'::text[] NOT NULL,
    registration_note text,
    description text,
    patent_source_url text,
    regulatory_evidence_url text,
    source_table text DEFAULT 'scaffold_sequence_database.tsv'::text NOT NULL,
    source_version date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scaffold_library_category_check CHECK (((category IS NULL) OR (category = ANY (ARRAY['spider-silk'::text, 'silkworm-silk'::text, 'recombinant-collagen'::text])))),
    CONSTRAINT scaffold_library_max_evidence_check CHECK (((max_evidence IS NULL) OR (max_evidence = ANY (ARRAY['E1'::text, 'E2'::text, 'E3'::text, 'E4'::text, 'E5'::text]))))
);


ALTER TABLE public.scaffold_library OWNER TO igem;

--
-- Name: scaffold_library_sequences; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.scaffold_library_sequences (
    sequence_id text NOT NULL,
    scaffold_id text NOT NULL,
    fasta_filename text,
    length_aa integer NOT NULL,
    aa_sequence text NOT NULL,
    sha256 character(64),
    product_use text,
    potential_uses text,
    regulatory_status text,
    safety_testing_summary text,
    evidence_level text,
    experiment_group text,
    experiment_level text,
    specific_experiments text,
    principal_result text,
    result_location text,
    evidence_limitations text,
    patent_source_url text,
    regulatory_evidence_url text,
    confidence_limitations text,
    source_version date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scaffold_library_sequences_evidence_level_check CHECK (((evidence_level IS NULL) OR (evidence_level = ANY (ARRAY['E1'::text, 'E2'::text, 'E3'::text, 'E4'::text, 'E5'::text]))))
);


ALTER TABLE public.scaffold_library_sequences OWNER TO igem;

--
-- Name: scaffold_patent_records; Type: TABLE; Schema: public; Owner: igem
--

CREATE TABLE public.scaffold_patent_records (
    id bigint NOT NULL,
    record_id text,
    fasta_filename text,
    aa_sequence text,
    length_aa integer,
    patent_family text NOT NULL,
    applicant text NOT NULL,
    protein_construct text,
    product_intended_use text,
    potential_application text,
    regulatory_status text,
    testing_summary text,
    highest_evidence_level text,
    fasta_availability text,
    pdb_accession text,
    patent_source_url text,
    regulatory_evidence_url text,
    confidence_limitations text,
    scaffold_group_key text,
    source_version date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scaffold_patent_records_highest_evidence_level_check CHECK ((highest_evidence_level = ANY (ARRAY['E1'::text, 'E2'::text, 'E3'::text, 'E4'::text, 'E5'::text])))
);


ALTER TABLE public.scaffold_patent_records OWNER TO igem;

--
-- Name: scaffold_patent_records_id_seq; Type: SEQUENCE; Schema: public; Owner: igem
--

CREATE SEQUENCE public.scaffold_patent_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scaffold_patent_records_id_seq OWNER TO igem;

--
-- Name: scaffold_patent_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: igem
--

ALTER SEQUENCE public.scaffold_patent_records_id_seq OWNED BY public.scaffold_patent_records.id;


--
-- Name: v_peptide_enrichment_coverage; Type: VIEW; Schema: public; Owner: igem
--

CREATE VIEW public.v_peptide_enrichment_coverage AS
 SELECT t.tool,
    COALESCE(c.done, (0)::bigint) AS done_count,
    COALESCE(c.tool_eligible, (0)::bigint) AS eligible_count,
        CASE
            WHEN (COALESCE(c.tool_eligible, (0)::bigint) = 0) THEN (0)::numeric
            ELSE round(((100.0 * (c.done)::numeric) / (c.tool_eligible)::numeric), 2)
        END AS coverage_pct
   FROM (( VALUES ('toxinpred3'::text,'1-30'::text), ('tipred'::text,'1-30'::text), ('algpred2'::text,'1-30'::text), ('sodope'::text,'1-30'::text), ('anoxpepred'::text,'1-30'::text), ('anoxpepred-frs'::text,'1-30'::text), ('anoxpepred-chelating'::text,'1-30'::text), ('hemopi2'::text,'1-40'::text), ('plm4cpps'::text,'length_supported'::text), ('temstapro'::text,'length_supported'::text), ('mhcflurry'::text,'5-15'::text), ('amp-esm'::text,'1-30'::text)) t(tool, eligible_filter)
     LEFT JOIN ( SELECT peptide_enrichment.tool,
            count(*) AS done,
                CASE peptide_enrichment.tool
                    WHEN 'mhcflurry'::text THEN ( SELECT count(*) AS count
                       FROM public.peptides
                      WHERE ((peptides.length >= 5) AND (peptides.length <= 15)))
                    WHEN 'hemopi2'::text THEN ( SELECT count(*) AS count
                       FROM public.peptides
                      WHERE (peptides.length <= 40))
                    ELSE ( SELECT count(*) AS count
                       FROM public.peptides)
                END AS tool_eligible
           FROM public.peptide_enrichment
          GROUP BY peptide_enrichment.tool) c ON (((c.tool)::text = t.tool)))
  ORDER BY
        CASE
            WHEN (COALESCE(c.tool_eligible, (0)::bigint) = 0) THEN (0)::numeric
            ELSE round(((100.0 * (c.done)::numeric) / (c.tool_eligible)::numeric), 2)
        END DESC NULLS LAST, t.tool;


ALTER VIEW public.v_peptide_enrichment_coverage OWNER TO igem;

--
-- Name: backbone_proteins id; Type: DEFAULT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.backbone_proteins ALTER COLUMN id SET DEFAULT nextval('public.backbone_proteins_id_seq'::regclass);


--
-- Name: constructs id; Type: DEFAULT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.constructs ALTER COLUMN id SET DEFAULT nextval('public.constructs_id_seq'::regclass);


--
-- Name: dataset_manifest id; Type: DEFAULT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.dataset_manifest ALTER COLUMN id SET DEFAULT nextval('public.dataset_manifest_id_seq'::regclass);


--
-- Name: linkers id; Type: DEFAULT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.linkers ALTER COLUMN id SET DEFAULT nextval('public.linkers_id_seq'::regclass);


--
-- Name: netmhc_score id; Type: DEFAULT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.netmhc_score ALTER COLUMN id SET DEFAULT nextval('public.netmhc_score_id_seq'::regclass);


--
-- Name: peptides id; Type: DEFAULT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.peptides ALTER COLUMN id SET DEFAULT nextval('public.peptides_id_seq'::regclass);


--
-- Name: scaffold_experiments id; Type: DEFAULT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_experiments ALTER COLUMN id SET DEFAULT nextval('public.scaffold_experiments_id_seq'::regclass);


--
-- Name: scaffold_patent_records id; Type: DEFAULT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_patent_records ALTER COLUMN id SET DEFAULT nextval('public.scaffold_patent_records_id_seq'::regclass);


--
-- Name: backbone_proteins backbone_proteins_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.backbone_proteins
    ADD CONSTRAINT backbone_proteins_pkey PRIMARY KEY (id);


--
-- Name: constructs constructs_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.constructs
    ADD CONSTRAINT constructs_pkey PRIMARY KEY (id);


--
-- Name: dataset_manifest dataset_manifest_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.dataset_manifest
    ADD CONSTRAINT dataset_manifest_pkey PRIMARY KEY (id);


--
-- Name: dataset_manifest dataset_manifest_uniq; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.dataset_manifest
    ADD CONSTRAINT dataset_manifest_uniq UNIQUE (source, source_version, source_file);


--
-- Name: linker_library linker_library_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.linker_library
    ADD CONSTRAINT linker_library_pkey PRIMARY KEY (id);


--
-- Name: linker_library linker_library_seq_uniq; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.linker_library
    ADD CONSTRAINT linker_library_seq_uniq UNIQUE (sequence);


--
-- Name: linkers linkers_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.linkers
    ADD CONSTRAINT linkers_pkey PRIMARY KEY (id);


--
-- Name: netmhc_score netmhc_score_peptide_allele_uniq; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.netmhc_score
    ADD CONSTRAINT netmhc_score_peptide_allele_uniq UNIQUE (peptide, allele);


--
-- Name: netmhc_score netmhc_score_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.netmhc_score
    ADD CONSTRAINT netmhc_score_pkey PRIMARY KEY (id);


--
-- Name: peptide_enrichment peptide_enrichment_pk; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.peptide_enrichment
    ADD CONSTRAINT peptide_enrichment_pk PRIMARY KEY (peptide_id, tool);


--
-- Name: peptide_metadata peptide_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.peptide_metadata
    ADD CONSTRAINT peptide_metadata_pkey PRIMARY KEY (peptide_id);


--
-- Name: peptides peptides_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.peptides
    ADD CONSTRAINT peptides_pkey PRIMARY KEY (id);


--
-- Name: peptides peptides_seq_source_ver_uniq; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.peptides
    ADD CONSTRAINT peptides_seq_source_ver_uniq UNIQUE (sequence, source, source_version);


--
-- Name: scaffold_experiments scaffold_experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_experiments
    ADD CONSTRAINT scaffold_experiments_pkey PRIMARY KEY (id);


--
-- Name: scaffold_groups scaffold_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_groups
    ADD CONSTRAINT scaffold_groups_pkey PRIMARY KEY (scaffold_group_key);


--
-- Name: scaffold_library scaffold_library_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_library
    ADD CONSTRAINT scaffold_library_pkey PRIMARY KEY (id);


--
-- Name: scaffold_library_sequences scaffold_library_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_library_sequences
    ADD CONSTRAINT scaffold_library_sequences_pkey PRIMARY KEY (sequence_id);


--
-- Name: scaffold_patent_records scaffold_patent_records_pkey; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_patent_records
    ADD CONSTRAINT scaffold_patent_records_pkey PRIMARY KEY (id);


--
-- Name: scaffold_patent_records scaffold_patent_records_record_id_key; Type: CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_patent_records
    ADD CONSTRAINT scaffold_patent_records_record_id_key UNIQUE (record_id);


--
-- Name: constructs_direction_channel_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX constructs_direction_channel_idx ON public.constructs USING btree (direction, channel, status);


--
-- Name: constructs_direction_rank_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX constructs_direction_rank_idx ON public.constructs USING btree (direction, status, rank);


--
-- Name: constructs_uniq_combo; Type: INDEX; Schema: public; Owner: igem
--

CREATE UNIQUE INDEX constructs_uniq_combo ON public.constructs USING btree (direction, backbone_id, linker_id, peptide_id);


--
-- Name: dataset_manifest_source_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX dataset_manifest_source_idx ON public.dataset_manifest USING btree (source, source_version);


--
-- Name: dataset_manifest_status_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX dataset_manifest_status_idx ON public.dataset_manifest USING btree (status);


--
-- Name: idx_netmhc_score_allele; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX idx_netmhc_score_allele ON public.netmhc_score USING btree (allele);


--
-- Name: idx_netmhc_score_allele_bind; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX idx_netmhc_score_allele_bind ON public.netmhc_score USING btree (allele, bind_level) WHERE (bind_level = ANY (ARRAY['SB'::text, 'WB'::text]));


--
-- Name: idx_netmhc_score_peptide; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX idx_netmhc_score_peptide ON public.netmhc_score USING btree (peptide);


--
-- Name: linker_library_length_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX linker_library_length_idx ON public.linker_library USING btree (length);


--
-- Name: linker_library_rigidity_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX linker_library_rigidity_idx ON public.linker_library USING btree (rigidity);


--
-- Name: peptide_enrichment_tool_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX peptide_enrichment_tool_idx ON public.peptide_enrichment USING btree (tool);


--
-- Name: peptide_enrichment_tool_score_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX peptide_enrichment_tool_score_idx ON public.peptide_enrichment USING btree (tool, score DESC NULLS LAST);


--
-- Name: peptide_meta_pdb_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX peptide_meta_pdb_idx ON public.peptide_metadata USING btree (pdb_id) WHERE (pdb_id IS NOT NULL);


--
-- Name: peptide_meta_tax_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX peptide_meta_tax_idx ON public.peptide_metadata USING btree (taxonomy) WHERE (taxonomy IS NOT NULL);


--
-- Name: peptides_length_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX peptides_length_idx ON public.peptides USING btree (length);


--
-- Name: peptides_seq_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX peptides_seq_idx ON public.peptides USING btree (sequence);


--
-- Name: peptides_seq_md5_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX peptides_seq_md5_idx ON public.peptides USING btree (seq_md5);


--
-- Name: peptides_source_ver_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX peptides_source_ver_idx ON public.peptides USING btree (source, source_version);


--
-- Name: scaffold_experiments_evlevel_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_experiments_evlevel_idx ON public.scaffold_experiments USING btree (highest_level);


--
-- Name: scaffold_experiments_group_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_experiments_group_idx ON public.scaffold_experiments USING btree (scaffold_group_key);


--
-- Name: scaffold_experiments_srcver_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_experiments_srcver_idx ON public.scaffold_experiments USING btree (source_version);


--
-- Name: scaffold_groups_name_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_groups_name_idx ON public.scaffold_groups USING btree (scaffold_group_name);


--
-- Name: scaffold_lib_seq_evidence_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_lib_seq_evidence_idx ON public.scaffold_library_sequences USING btree (evidence_level);


--
-- Name: scaffold_lib_seq_scaffold_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_lib_seq_scaffold_idx ON public.scaffold_library_sequences USING btree (scaffold_id);


--
-- Name: scaffold_library_applicant_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_library_applicant_idx ON public.scaffold_library USING btree (applicant);


--
-- Name: scaffold_library_category_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_library_category_idx ON public.scaffold_library USING btree (category);


--
-- Name: scaffold_library_evidence_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_library_evidence_idx ON public.scaffold_library USING btree (max_evidence);


--
-- Name: scaffold_library_routes_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_library_routes_idx ON public.scaffold_library USING gin (route_ids);


--
-- Name: scaffold_patent_records_applicant_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_patent_records_applicant_idx ON public.scaffold_patent_records USING btree (applicant);


--
-- Name: scaffold_patent_records_evlevel_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_patent_records_evlevel_idx ON public.scaffold_patent_records USING btree (highest_evidence_level);


--
-- Name: scaffold_patent_records_group_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_patent_records_group_idx ON public.scaffold_patent_records USING btree (scaffold_group_key);


--
-- Name: scaffold_patent_records_patent_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_patent_records_patent_idx ON public.scaffold_patent_records USING btree (patent_family);


--
-- Name: scaffold_patent_records_srcver_idx; Type: INDEX; Schema: public; Owner: igem
--

CREATE INDEX scaffold_patent_records_srcver_idx ON public.scaffold_patent_records USING btree (source_version);


--
-- Name: constructs constructs_backbone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.constructs
    ADD CONSTRAINT constructs_backbone_id_fkey FOREIGN KEY (backbone_id) REFERENCES public.backbone_proteins(id);


--
-- Name: constructs constructs_linker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.constructs
    ADD CONSTRAINT constructs_linker_id_fkey FOREIGN KEY (linker_id) REFERENCES public.linkers(id);


--
-- Name: constructs constructs_peptide_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.constructs
    ADD CONSTRAINT constructs_peptide_id_fkey FOREIGN KEY (peptide_id) REFERENCES public.peptides(id);


--
-- Name: peptide_enrichment peptide_enrichment_peptide_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.peptide_enrichment
    ADD CONSTRAINT peptide_enrichment_peptide_id_fkey FOREIGN KEY (peptide_id) REFERENCES public.peptides(id) ON DELETE CASCADE;


--
-- Name: peptide_metadata peptide_metadata_peptide_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.peptide_metadata
    ADD CONSTRAINT peptide_metadata_peptide_id_fkey FOREIGN KEY (peptide_id) REFERENCES public.peptides(id) ON DELETE CASCADE;


--
-- Name: scaffold_experiments scaffold_experiments_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_experiments
    ADD CONSTRAINT scaffold_experiments_group_fk FOREIGN KEY (scaffold_group_key) REFERENCES public.scaffold_groups(scaffold_group_key);


--
-- Name: scaffold_library_sequences scaffold_library_sequences_scaffold_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_library_sequences
    ADD CONSTRAINT scaffold_library_sequences_scaffold_id_fkey FOREIGN KEY (scaffold_id) REFERENCES public.scaffold_library(id) ON DELETE CASCADE;


--
-- Name: scaffold_patent_records scaffold_patent_records_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: igem
--

ALTER TABLE ONLY public.scaffold_patent_records
    ADD CONSTRAINT scaffold_patent_records_group_fk FOREIGN KEY (scaffold_group_key) REFERENCES public.scaffold_groups(scaffold_group_key);


--
-- PostgreSQL database dump complete
--

\unrestrict ivLVEeWwIDLbXtj8MRiX5KqnYVwbawfsPIkkymYVgN7ydlsKF0n40EIa1jSbJS2

